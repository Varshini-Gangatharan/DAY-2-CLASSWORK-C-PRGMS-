/******************************************************************************

Welcome to GDB Online.
GDB online is an online compiler and debugger tool for C, C++, Python, Java, PHP, Ruby, Perl,
C#, OCaml, VB, Swift, Pascal, Fortran, Haskell, Objective-C, Assembly, HTML, CSS, JS, SQLite, Prolog.
Code, Compile, Run and Debug online from anywhere in world.

*******************************************************************************/
#include<stdio.h>
int main()
{
    int a[50],i,n,large,small;
    printf("How many elements:");
    scanf("%d",&n);
    printf("Enter the Array:");
    for(i=0;i<n;++i)
    scanf("%d",&a[i]);
    large=small=a[0];
    for(i=1;i<n;++i)
    {
        if(a[i]>large)
        large=a[i];
        if(a[i]<small)
        small=a[i];
        }
    printf("The largest element is %d",large);
    printf("\nThe smallest element is %d",small);
return 0;
}