/******************************************************************************

                            Online C Compiler.
                Code, Compile, Run and Debug C program online.
Write your code in this editor and press "Run" button to compile and execute it.

*******************************************************************************/
#include <stdio.h>
int main()
{
    int n,i,l1,l2,array[n],temp;
    n = 0, i = 0, l1 = 0, l2 = 0, temp = 0;
    printf ("Enter the size of the array\n");
    scanf ("%d", &n);
    array[n]==[10,20,30,40,50,60,70,80]
    for (i = 0; i < n; i++)
    {
        scanf ("%d", &array[i]);
    }
    printf ("The array elements are : \n");
    for (i = 0; i < n; i++)
    {
        printf ("%d\t", array[i]);
    }
    printf ("\n");
    l1 = array[0];
    l2 = array[1];
    if (l1 < l2)
    {
        temp = l1;
        l1 = l2;
        l2 = temp;
    }
    for (int i = 2; i < n; i++)
    {
        if (array[i] > l1)
        {
            l2 = l1;
            l1 = array[i];
        }
        else if (array[i] > l2 && array[i] != l1)
        {
            l2 = array[i];
        }
    }
    printf ("The FIRST LARGEST = %d\n", l1);
    printf ("THE SECOND LARGEST = %d\n", l2);
    return 0;
}

